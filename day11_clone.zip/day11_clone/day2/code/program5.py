age1 = 4
if age1 >= 18:
    # if block
    # will be executed when the condition returns True
    print("Yes")
    print("Another statement in if block")
else:
    # else block
    # will be executed when the condition returns False
    print("No")
    print("Another statement in else block")


age2 = 30
if age2 >= 18:
    print("Yes")
else:
    print("No")

age3 = 80
if age3 >= 18:
    print("Yes")
else:
    print("No")


