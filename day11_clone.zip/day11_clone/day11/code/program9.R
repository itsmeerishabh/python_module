# excercise 1: indexing

ages = c(19, 10, 9, 6, 20, 39, 89, 100)
# use +ve, -ve and logical indexing

# [19, 10, 9]
# [6, 20, 39]
# 100
# 20
# 89


# excercise 2: slicing
# [6, 20, 39, 89]
# [39, 89, 100]

# excercise 3: filtering
# find the persons eligible for voting
# find the persons eligible for voting