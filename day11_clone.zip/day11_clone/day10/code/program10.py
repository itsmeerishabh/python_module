# multiple inheritance
# - single derived class having multiple base classes

class Teacher:
    pass


class LabAssistant:
    pass


class TeacherLabAssistant(Teacher, LabAssistant):
    pass
