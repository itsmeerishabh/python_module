# Hierarchical inheritance
# - one base class has many derived classed

class Person:
    pass


class Student(Person):
    pass


class Employee(Person):
    pass


class Player(Person):
    pass
