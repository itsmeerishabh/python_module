# single inheritance
# - also known as simple inheritance
# - there is only one base class and one derived class

class Person:
    pass


class Student(Person):
    pass
