# hybrid inheritance
# - combination of more than two inheritance types

class Person:
    pass

class Employee:
    pass

class Manager(Employee):
    pass

class Student(Person):
    pass